#include<iostream>
#include"math/MathF.h"
int main(){

std::cout << "int";
j();
  return 0 ; 
}
