#include<iostream>
void j(); 
