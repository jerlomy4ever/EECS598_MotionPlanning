#include "MathF.h"
void j(){
	std::cout << "777777777";
}
